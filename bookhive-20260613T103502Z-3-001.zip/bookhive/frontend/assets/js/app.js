/* =========================
   BOOK DATA
========================= */
let allBooks = [];

/* FETCH BOOKS FROM API */
fetch("../api/books.php")
    .then(res => res.json())
    .then(data => {
        allBooks = data;
        renderBooks(allBooks);
    });

/* =========================
   RENDER FUNCTION (DOM MANIPULATION)
========================= */
function renderBooks(books) {
    const container = document.querySelector("#books");
    container.innerHTML = "";

    books.forEach(book => {
        const card = document.createElement("article");
        card.className = "book-card";

        card.innerHTML = `
            <h3>${book.title}</h3>
            <p><strong>Author:</strong> ${book.author}</p>
            <p><strong>Category:</strong> ${book.category}</p>
            <p><strong>Available:</strong> ${book.available_copies}</p>
        `;

        container.appendChild(card);
    });
}

/* =========================
   LIVE SEARCH + FILTER
========================= */
const searchInput = document.querySelector("#search");
const categoryFilter = document.querySelector("#categoryFilter");

function filterBooks() {
    let searchValue = searchInput.value.toLowerCase();
    let categoryValue = categoryFilter.value;

    let filtered = allBooks.filter(book => {
        let matchesSearch =
            book.title.toLowerCase().includes(searchValue) ||
            book.author.toLowerCase().includes(searchValue);

        let matchesCategory =
            categoryValue === "all" ||
            book.category === categoryValue;

        return matchesSearch && matchesCategory;
    });

    renderBooks(filtered);
}

searchInput.addEventListener("input", filterBooks);
categoryFilter.addEventListener("change", filterBooks);

const registerForm = document.querySelector("#registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", function (e) {
        e.preventDefault();

        let name = document.querySelector("#name").value.trim();
        let email = document.querySelector("#email").value.trim();
        let password = document.querySelector("#password").value.trim();

        let nameError = document.querySelector("#nameError");
        let emailError = document.querySelector("#emailError");
        let passwordError = document.querySelector("#passwordError");

        nameError.textContent = "";
        emailError.textContent = "";
        passwordError.textContent = "";

        let isValid = true;

        // NAME validation
        if (name === "") {
            nameError.textContent = "Name is required";
            isValid = false;
        }

        // EMAIL validation
        if (email === "") {
            emailError.textContent = "Email is required";
            isValid = false;
        } else if (!email.includes("@")) {
            emailError.textContent = "Invalid email format";
            isValid = false;
        }

        // PASSWORD validation
        if (password === "") {
            passwordError.textContent = "Password is required";
            isValid = false;
        } else if (password.length < 6) {
            passwordError.textContent = "Password must be at least 6 characters";
            isValid = false;
        }

        if (isValid) {
            alert("Registration successful!");
            registerForm.reset();
        }
    });
}